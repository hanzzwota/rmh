# Rumah Kosong di Ujung Kampung — Remotion 3D (1080x1920, 30fps)

```bash
npm install
npm run studio     # preview
npm run render     # hasil: out/rumah-kosong.mp4 (H.264)
```
Butuh Node 18+ dan Chrome (Remotion mengunduhnya otomatis). Render 1917 frame 3D ± 10–30 menit.
Jika render gagal/blank: ganti `--gl=angle` dengan `--gl=swiftshader` di package.json.

Sinkron subtitle/adegan: waktu tiap kalimat diperkirakan dari panjang teks (src/story.ts).
Jika geser, isi `MANUAL_STARTS` dengan detik mulai 13 kalimat, atau ubah LEAD/TAIL.
