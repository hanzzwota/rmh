import React, {useMemo} from 'react';
import * as THREE from 'three';
import {useCurrentFrame} from 'remotion';

export type PersonProps = {
  pos: [number, number, number]; rotY: number; top: string; pants: string; hair: string;
  skin?: string; hat?: boolean; skirt?: boolean; bun?: boolean; scale?: number; headScale?: number;
  phase?: number; walk?: number; talk?: number; nerv?: number; lookY?: number; jump?: number;
  flash?: boolean; hood?: boolean; shirt?: string; gesture?: number;
};
const Bx = ({p, s, c, r}: any) => (
  <mesh position={p} scale={s} rotation={r} castShadow>
    <boxGeometry args={[1, 1, 1]} /><meshStandardMaterial color={c} flatShading />
  </mesh>
);
const Sp = ({p, s, c, args = [1, 16, 16]}: any) => (
  <mesh position={p} scale={s} castShadow>
    <sphereGeometry args={args} /><meshStandardMaterial color={c} flatShading />
  </mesh>
);

export const Person: React.FC<PersonProps> = (P) => {
  const f = useCurrentFrame();
  const t = f / 30;
  const {phase = 0, walk = 0, talk = 0, nerv = 0, lookY = 0, jump = 0, scale = 1, skin = '#e0ac84', gesture = 0} = P;
  const sw = Math.sin(phase) * walk;
  const blink = f % 96 < 4 ? 0.1 : 1;
  const bob = Math.abs(Math.cos(phase)) * 0.05 * walk + Math.sin(t * 2) * 0.01;
  const mouth = 0.25 + Math.abs(Math.sin(t * 11)) * talk * 0.9;
  const shake = nerv ? Math.sin(t * 38) * 0.012 * nerv : 0;
  const tgt = useMemo(() => new THREE.Object3D(), []);
  const gest = gesture ? Math.sin(t * 3.2) * 0.5 * gesture : 0;
  return (
    <group position={[P.pos[0] + shake, P.pos[1] + jump, P.pos[2]]} rotation={[0, P.rotY, 0]} scale={scale}>
      <group position={[0, bob, 0]}>
        {/* kaki / sarung */}
        {P.skirt ? (
          <mesh position={[0, 0.5, 0]} castShadow><cylinderGeometry args={[0.38, 0.5, 0.95, 10]} /><meshStandardMaterial color={P.pants} flatShading /></mesh>
        ) : ([-1, 1] as const).map((s) => (
          <group key={s} position={[s * 0.18, 0.78, 0]} rotation={[sw * s * 0.7, 0, 0]}>
            <Bx p={[0, -0.36, 0]} s={[0.24, 0.72, 0.26]} c={P.pants} />
            <Bx p={[0, -0.76, 0.05]} s={[0.26, 0.12, 0.38]} c="#2a2a2a" />
          </group>
        ))}
        {/* badan */}
        <Bx p={[0, 1.18, 0]} s={[0.74, 0.8, 0.42]} c={P.top} />
        {P.shirt && <Bx p={[0, 1.1, 0.215]} s={[0.34, 0.5, 0.02]} c={P.shirt} />}
        {P.hood && <Sp p={[0, 1.62, -0.2]} s={[0.36, 0.22, 0.26]} c={P.top} />}
        {/* lengan */}
        <group position={[-0.47, 1.52, 0]} rotation={[P.flash ? -1.3 : -sw * 0.6 + gest, 0, 0.05]}>
          <Bx p={[0, -0.3, 0]} s={[0.18, 0.66, 0.2]} c={P.top} />
          <Sp p={[0, -0.68, 0]} s={[0.1, 0.1, 0.1]} c={skin} />
        </group>
        <group position={[0.47, 1.52, 0]} rotation={[sw * 0.6 - gest, 0, -0.05]}>
          <Bx p={[0, -0.3, 0]} s={[0.18, 0.66, 0.2]} c={P.top} />
          <Sp p={[0, -0.68, 0]} s={[0.1, 0.1, 0.1]} c={skin} />
        </group>
        {P.flash && (
          <group position={[-0.47, 1.0, 0.55]}>
            <mesh rotation={[Math.PI / 2, 0, 0]} castShadow><cylinderGeometry args={[0.06, 0.07, 0.28, 8]} /><meshStandardMaterial color="#222" /></mesh>
            <mesh position={[0, 0, 0.15]} rotation={[Math.PI / 2, 0, 0]}><cylinderGeometry args={[0.075, 0.075, 0.03, 8]} /><meshStandardMaterial color="#fff6c0" emissive="#fff0a0" emissiveIntensity={2} /></mesh>
            <primitive object={tgt} position={[0, -0.6, 7]} />
            <spotLight position={[0, 0, 0.2]} target={tgt} angle={0.5} penumbra={0.7} intensity={90} distance={26} color="#fff0b8" castShadow />
            <mesh position={[0, 0, 3.4]} rotation={[Math.PI / 2, 0, 0]}>
              <cylinderGeometry args={[1.3, 0.04, 6.4, 16, 1, true]} />
              <meshBasicMaterial color="#fff2b0" transparent opacity={0.1} depthWrite={false} blending={THREE.AdditiveBlending} side={THREE.DoubleSide} />
            </mesh>
          </group>
        )}
        {/* kepala */}
        <group position={[0, 1.98, 0]} rotation={[0, lookY, 0]} scale={P.headScale || 1}>
          <Sp p={[0, 0, 0]} s={[0.38, 0.4, 0.38]} c={skin} />
          <mesh position={[0, 0.04, -0.02]} rotation={[-0.3, 0, 0]} castShadow>
            <sphereGeometry args={[0.41, 16, 16, 0, Math.PI * 2, 0, Math.PI * 0.56]} /><meshStandardMaterial color={P.hair} flatShading />
          </mesh>
          {P.bun && <Sp p={[0, 0.3, -0.3]} s={[0.17, 0.17, 0.17]} c={P.hair} />}
          {([-1, 1] as const).map((s) => (
            <group key={s}>
              <Sp p={[s * 0.14, 0.04, 0.34]} s={[0.055, 0.07 * blink, 0.04]} c="#111" />
              <Bx p={[s * 0.14, 0.17 + nerv * 0.03, 0.35]} s={[0.12, 0.025, 0.03]} c="#222" r={[0, 0, -s * nerv * 0.35]} />
            </group>
          ))}
          <Sp p={[0, -0.04, 0.38]} s={[0.04, 0.04, 0.04]} c={skin} />
          <Bx p={[0, -0.16, 0.34]} s={[0.13 + nerv * 0.03, 0.04 + mouth * 0.07, 0.03]} c="#5a1f1f" />
          {P.hat && (
            <mesh position={[0, 0.3, 0]} castShadow><cylinderGeometry args={[0.02, 0.82, 0.38, 20]} /><meshStandardMaterial color="#c9a45c" flatShading /></mesh>
          )}
        </group>
      </group>
    </group>
  );
};
