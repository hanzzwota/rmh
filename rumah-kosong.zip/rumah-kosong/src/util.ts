export const clamp = (x: number, a = 0, b = 1) => Math.min(b, Math.max(a, x));
export const lerp = (a: number, b: number, t: number) => a + (b - a) * t;
export const ss = (x: number) => {const t = clamp(x); return t * t * (3 - 2 * t);};
// keyframes: [time, v1, v2, ...]; smooth=true eases each segment
export const K = (t: number, k: number[][], smooth = true): number[] => {
  if (t <= k[0][0]) return k[0].slice(1);
  for (let i = 0; i < k.length - 1; i++) {
    if (t <= k[i + 1][0]) {
      const raw = (t - k[i][0]) / (k[i + 1][0] - k[i][0]);
      const u = smooth ? ss(raw) : raw;
      return k[i].slice(1).map((v, j) => lerp(v, k[i + 1][j + 1], u));
    }
  }
  return k[k.length - 1].slice(1);
};
export const rnd = (n: number) => {const x = Math.sin(n * 127.1 + 311.7) * 43758.5453; return x - Math.floor(x);};
