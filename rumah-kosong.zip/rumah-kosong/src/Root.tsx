import React from 'react';
import {Composition} from 'remotion';
import {Main} from './Main';
import {DURATION, FPS} from './story';
export const Root: React.FC = () => (
  <Composition id="Main" component={Main} durationInFrames={DURATION} fps={FPS} width={1080} height={1920} />
);
