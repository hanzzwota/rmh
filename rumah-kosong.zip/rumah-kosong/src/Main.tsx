import React from 'react';
import {AbsoluteFill, Audio, Sequence, staticFile, useCurrentFrame, interpolate} from 'remotion';
import {ThreeCanvas} from '@remotion/three';
import {useThree} from '@react-three/fiber';
import * as THREE from 'three';
import {K, lerp, ss, clamp, rnd} from './util';
import {FPS, DURATION, END, SENTENCES, st, et, slamT, argaZ, argaWalking} from './story';
import {Person} from './Characters';
import {House, BigTree, Coconut, Banana, Hut, Pole, Fence, Grass} from './World';

const face = (x: number, z: number, cx: number, cz: number) => Math.atan2(cx - x, cz - z);

// ---------- langit / cahaya sepanjang waktu ----------
const SKY = (t: number) => {
  const k = [
    {t: 0, sky: '#bfe3f2', fog: '#d4ead8', sun: '#fff2d0', si: 1.7, amb: 0.9, night: 0},
    {t: st(3), sky: '#f4b27a', fog: '#f0c49a', sun: '#ff9a4a', si: 1.4, amb: 0.65, night: 0},
    {t: st(6) - 1, sky: '#4b3a58', fog: '#5a4560', sun: '#8a74b0', si: 0.6, amb: 0.4, night: 0.3},
    {t: st(7), sky: '#0a1224', fog: '#1b2740', sun: '#8fb0ff', si: 0.75, amb: 0.26, night: 1},
  ];
  let i = 0; while (i < k.length - 1 && t > k[i + 1].t) i++;
  const a = k[i], b = k[Math.min(i + 1, k.length - 1)];
  const u = a === b ? 0 : ss((t - a.t) / (b.t - a.t));
  const c = (x: string, y: string) => new THREE.Color(x).lerp(new THREE.Color(y), u);
  return {sky: c(a.sky, b.sky), fog: c(a.fog, b.fog), sun: c(a.sun, b.sun), si: lerp(a.si, b.si, u), amb: lerp(a.amb, b.amb, u), night: lerp(a.night, b.night, u)};
};

// ---------- kamera ----------
const CAM = (t: number): {p: number[]; l: number[]} => {
  const z = argaZ(t), ax = 0.4;
  const s2 = st(2), e2 = et(2), s3 = st(3), s6 = st(6), s7 = st(7), s9 = st(9), s11 = st(11), s12 = st(12), s13 = st(13);
  if (t < s3) {
    const v = K(t, [[0, -18, 9, 64, 0, 3, 12], [s2, -11, 6, 52, 0, 3, 6], [e2, 3, 3.4, 17, 0, 2.6, 0], [s3, 3, 3.4, 17, 0, 2.6, 0]]);
    return {p: v.slice(0, 3), l: v.slice(3)};
  }
  if (t < s6) {
    const v = K(t, [[s3, 0.5, 2.2, 16.5, 4, 1.5, 24], [s6, 2.5, 1.9, 19, 4, 1.5, 24]]);
    return {p: v.slice(0, 3), l: v.slice(3)};
  }
  if (t < s7) {
    const fp = [ax - 4.5, 2.0, z + 7], fl = [0, 1.4, z - 4];
    const u = ss((t - s6) / 1.5);
    const a = K(s6, [[s6, 2.5, 1.9, 19, 4, 1.5, 24]]);
    return {p: fp.map((v, i) => lerp(a[i], v, u)), l: fl.map((v, i) => lerp(a[i + 3], v, u))};
  }
  if (t < s9) {
    const v = K(t, [[s7, 2.6, 1.9, 12, 0, 1.6, 2.6], [s9, 1.8, 1.7, 10, 0, 1.6, 2.6]]);
    return {p: v.slice(0, 3), l: v.slice(3)};
  }
  if (t < s11) {
    const v = K(t, [[s9, 1.9, 1.7, 10.5, 0, 1.5, 2.4], [s11, 2.2, 1.6, 8.5, 0.4, 1.4, 2.8]]);
    return {p: v.slice(0, 3), l: v.slice(3)};
  }
  if (t < s12) {
    const v = K(t, [[s11, 2.4, 1.6, 9.5, 0.4, 1.4, 3.8], [slamT, 1.2, 1.6, 8.8, 0.4, 1.45, 4.6], [s12, 1.0, 1.55, 8.4, 0.4, 1.45, 4.8]]);
    const sh = t > slamT && t < slamT + 0.5 ? (1 - (t - slamT) / 0.5) * 0.08 : 0;
    return {p: [v[0] + Math.sin(t * 70) * sh, v[1] + Math.cos(t * 83) * sh, v[2]], l: v.slice(3)};
  }
  if (t < s13) {
    return {p: [6, 1.9, 10], l: [ax, 1.4, Math.min(z, 20)]};
  }
  const v = K(t, [[s13, 6, 1.9, 10, 0.4, 1.4, 22], [s13 + 3.5, 5, 2.0, 11, -1.8, 2.2, 2.6], [END, 0.2, 2.1, 7.2, -1.9, 2.3, 2.6]]);
  return {p: v.slice(0, 3), l: v.slice(3)};
};

const Rig: React.FC<{t: number; sk: ReturnType<typeof SKY>}> = ({t, sk}) => {
  const {camera, scene} = useThree();
  const c = CAM(t);
  camera.position.set(c.p[0], c.p[1], c.p[2]);
  camera.lookAt(c.l[0], c.l[1], c.l[2]);
  scene.background = sk.sky;
  scene.fog = new THREE.Fog(sk.fog, lerp(60, 14, sk.night * 0.9), lerp(210, 85, sk.night * 0.9));
  return null;
};

const World: React.FC = () => {
  const f = useCurrentFrame();
  const t = f / FPS;
  const sk = SKY(t);
  const s6 = st(6), s7 = st(7);
  const lit = t < s6 ? 0.2 : ss((t - s6) / 2) * 0.8 + 0.2;
  const open = t < s7 ? 0 : t < slamT ? ss((t - s7) / 1.2) * 0.42 : 0.42 * (1 - ss((t - slamT) / 0.15));
  const z = argaZ(t);
  const walking = argaWalking(t);
  const showArga = t > s6 - 1;
  const t11 = st(11);
  // arah Arga: menghadap rumah (-z); berbalik saat kalimat 11
  const yaw = t < t11 ? Math.PI : Math.PI * (1 - ss((t - t11) / 0.8));
  const look = t > slamT && t < st(12) + 1.2 ? Math.PI * 0.75 * ss((t - slamT) / 0.25) : 0;
  const jump = t > slamT && t < slamT + 0.35 ? 0.35 * Math.sin((Math.PI * (t - slamT)) / 0.35) : 0;
  const nerv = t > s7 ? 1 : t > s6 ? 0.4 : 0;
  const talking = t >= st(3) && t < st(6);
  const vis = t < st(6) - 0.3;
  const C = [4, 24];
  const trees: number[][] = [[-8, 0, -2], [8.5, 0, -3], [-9, 0, 5], [9, 0, 4], [-4, 0, -9], [5, 0, -9], [-13, 0, -8], [13, 0, 0]];
  return (
    <>
      <Rig t={t} sk={sk} />
      <ambientLight color={sk.night > 0.5 ? '#6f86c8' : '#ffffff'} intensity={sk.amb} />
      <hemisphereLight args={[sk.sky, '#3a4a2a', 0.35]} />
      <directionalLight position={[18, 30, 22]} color={sk.sun} intensity={sk.si} castShadow shadow-mapSize={[2048, 2048]}
        shadow-camera-left={-45} shadow-camera-right={45} shadow-camera-top={45} shadow-camera-bottom={-45} shadow-camera-far={120} />
      {/* bulan */}
      <mesh position={[-30, 38, -60]}><sphereGeometry args={[4, 24, 24]} /><meshBasicMaterial color="#f4f1dc" transparent opacity={sk.night} fog={false} /></mesh>
      {/* tanah */}
      <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow><planeGeometry args={[400, 400]} /><meshStandardMaterial color="#5f9a3b" /></mesh>
      {[[22, 28], [22, 46], [-22, 34], [-24, 54], [36, 36], [-38, 22]].map(([x, zz], i) => (
        <mesh key={i} rotation={[-Math.PI / 2, 0, 0]} position={[x, 0.03, zz]} receiveShadow>
          <planeGeometry args={[14 + rnd(i) * 8, 12]} /><meshStandardMaterial color={i % 2 ? '#7bb542' : '#8ec04c'} />
        </mesh>
      ))}
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, 0.02, 4]} receiveShadow><planeGeometry args={[22, 18]} /><meshStandardMaterial color="#667a36" /></mesh>
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, 0.04, 42]} receiveShadow><planeGeometry args={[3.2, 76]} /><meshStandardMaterial color="#8a6a45" /></mesh>
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, 0.06, 52]} receiveShadow><planeGeometry args={[2.4, 56]} /><meshStandardMaterial color="#9a9a96" /></mesh>
      {/* gunung jauh */}
      {[[-60, -120, 40], [10, -140, 55], [70, -110, 38], [-120, -40, 30], [120, 10, 34]].map(([x, zz, h], i) => (
        <mesh key={i} position={[x, h / 2 - 2, zz]}><coneGeometry args={[h * 1.1, h, 5]} /><meshStandardMaterial color="#4d6b66" flatShading /></mesh>
      ))}
      <House open={open} lit={lit} t={t} />
      {trees.map((p, i) => <BigTree key={i} p={p} t={t} i={i} h={6 + (i % 3)} />)}
      <Coconut p={[-14, 0, 12]} t={t} i={1} /><Coconut p={[14, 0, 20]} t={t} i={3} /><Coconut p={[-12, 0, 38]} t={t} i={5} />
      <Banana p={[-5.5, 0, 6]} t={t} i={1} /><Banana p={[5.8, 0, 7]} t={t} i={2} /><Banana p={[-11, 0, 18]} t={t} i={4} />
      {/* pagar bambu halaman (rusak), dengan celah gerbang */}
      <Fence from={[-9, 0, 9]} to={[-1.4, 0, 9]} broken seed={1} />
      <Fence from={[1.4, 0, 9]} to={[9, 0, 9]} broken seed={2} />
      <Fence from={[-9, 0, 9]} to={[-9, 0, -4]} broken seed={3} />
      <Fence from={[9, 0, 9]} to={[9, 0, -4]} broken seed={4} />
      <Grass t={t} area={[-8.5, 8.5, -3, 8.5]} n={130} />
      {/* kampung */}
      <Hut p={[-9, 0, 20]} ry={0.4} /><Hut p={[9.5, 0, 14]} ry={-0.5} wall="#a07a52" roof="#7a4636" />
      <Hut p={[-9.5, 0, 34]} ry={0.3} wall="#c0a070" /><Hut p={[9.5, 0, 36]} ry={-0.2} warung />
      <Hut p={[10, 0, 52]} ry={-0.4} wall="#b79468" roof="#6f4a40" /><Hut p={[-10, 0, 50]} ry={0.5} />
      <Pole p={[-2.4, 0, 16]} lamp={sk.night} /><Pole p={[2.4, 0, 30]} lamp={sk.night} /><Pole p={[-2.4, 0, 44]} lamp={sk.night} />
      <Banana p={[10, 0, 28]} t={t} i={7} /><Coconut p={[-14, 0, 26]} t={t} i={8} /><Coconut p={[15, 0, 46]} t={t} i={9} />
      {/* kabut tipis */}
      {[0, 1, 2, 3, 4, 5, 6].map((i) => (
        <mesh key={i} position={[((i * 7 + t * 0.6) % 28) - 14, 0.8, 2 + i * 4]} scale={[6, 0.9, 4]}>
          <sphereGeometry args={[1, 12, 8]} /><meshBasicMaterial color="#cfd8e6" transparent opacity={0.05 + sk.night * 0.12} depthWrite={false} />
        </mesh>
      ))}
      {/* warga desa */}
      {vis && (<>
        <Person pos={[3.1, 0, 24.7]} rotY={face(3.1, 24.7, C[0], C[1])} top="#6b5a3a" pants="#3b3b3b" hair="#d8d8d8" hat talk={talking ? 1 : 0} gesture={1} skin="#c99a70" scale={0.97} />
        <Person pos={[5.4, 0, 25]} rotY={face(5.4, 25, C[0], C[1])} top="#3f6f8f" pants="#4a3b2a" hair="#1b1b1b" talk={0.6} gesture={0.5} />
        <Person pos={[4.9, 0, 22.4]} rotY={face(4.9, 22.4, C[0], C[1])} top="#c55a6a" pants="#7a3e5a" hair="#1b1b1b" skirt bun talk={0.5} skin="#e3b48c" />
        <Person pos={[3.2, 0, 22.5]} rotY={face(3.2, 22.5, C[0], C[1])} top="#e6c04a" pants="#3d5a8a" hair="#1b1b1b" scale={0.62} headScale={1.25} skin="#e0ac84" />
      </>)}
      {/* Arga */}
      {showArga && (
        <Person pos={[0.4, 0, z]} rotY={yaw} top="#16161a" pants="#1a1a1f" hair="#0e0e10" shirt="#8d9096" hood flash
          phase={z * 1.6} walk={walking ? 0.75 : 0} nerv={nerv} lookY={look} jump={jump} />
      )}
    </>
  );
};

// ---------- subtitle ----------
const KEY = ['rumah', 'lampu', 'malam', 'pintu', 'kosong', 'siapa', 'tidak', 'berani', 'terbuka', 'tertutup', 'pertanyaan', 'dihuni', 'menyalakan', 'berhenti', 'berjalan'];
const chunks = SENTENCES.flatMap((s, i) => {
  const words = s.split(' '); const out: string[][] = [];
  for (let k = 0; k < words.length; k += 4) out.push(words.slice(k, k + 4));
  const total = out.reduce((a, c) => a + c.join(' ').length, 0);
  let acc = 0;
  return out.map((c) => {
    const a = st(i + 1) + ((et(i + 1) - st(i + 1)) * acc) / total;
    acc += c.join(' ').length;
    return {words: c, from: a, to: st(i + 1) + ((et(i + 1) - st(i + 1)) * acc) / total};
  });
});
const Subtitles: React.FC = () => {
  const f = useCurrentFrame(); const t = f / FPS;
  const ch = chunks.find((c) => t >= c.from && t < c.to + 0.05);
  if (!ch) return null;
  const pop = interpolate(t - ch.from, [0, 0.12], [0.85, 1], {extrapolateRight: 'clamp'});
  return (
    <div style={{position: 'absolute', left: 70, right: 70, bottom: 380, textAlign: 'center', transform: `scale(${pop})`}}>
      {ch.words.map((w, i) => {
        const clean = w.toLowerCase().replace(/[^a-z-]/g, '');
        const hi = KEY.includes(clean);
        return (
          <span key={i} style={{fontFamily: "'Arial Black', Impact, sans-serif", fontWeight: 900, fontSize: 78, lineHeight: 1.25,
            color: hi ? '#ffd84a' : '#fff', WebkitTextStroke: '8px #000', paintOrder: 'stroke fill', textShadow: '0 6px 14px rgba(0,0,0,.7)', marginRight: 18, display: 'inline-block'}}>{w}</span>
        );
      })}
    </div>
  );
};

const Overlay: React.FC = () => {
  const f = useCurrentFrame(); const t = f / FPS;
  const title = interpolate(t, [0.3, 1, 3.2, 4.2], [0, 1, 1, 0], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'});
  const fadeOut = interpolate(t, [END - 1, END], [0, 1], {extrapolateLeft: 'clamp'});
  const fadeIn = interpolate(t, [0, 0.8], [1, 0], {extrapolateRight: 'clamp'});
  const night = SKY(t).night;
  return (
    <>
      <AbsoluteFill style={{background: `radial-gradient(ellipse at center, rgba(0,0,0,0) 45%, rgba(0,0,0,${0.35 + night * 0.35}) 100%)`, pointerEvents: 'none'}} />
      <AbsoluteFill style={{background: night > 0.5 ? 'rgba(20,40,90,.16)' : 'rgba(255,170,80,.08)', mixBlendMode: 'soft-light' as any}} />
      <div style={{position: 'absolute', top: 300, width: '100%', textAlign: 'center', opacity: title, fontFamily: "'Arial Black', Impact, sans-serif", color: '#fff', textShadow: '0 8px 24px #000'}}>
        <div style={{fontSize: 118, fontWeight: 900, letterSpacing: 4, WebkitTextStroke: '6px #000', paintOrder: 'stroke fill'}}>RUMAH KOSONG</div>
        <div style={{fontSize: 52, marginTop: 8, color: '#ffd84a', WebkitTextStroke: '5px #000', paintOrder: 'stroke fill'}}>DI UJUNG KAMPUNG</div>
      </div>
      <AbsoluteFill style={{background: '#000', opacity: Math.max(fadeOut, fadeIn)}} />
    </>
  );
};

// ---------- audio ----------
const steps: number[] = [];
{
  let last = Math.floor((argaZ(0) * 1.6) / Math.PI);
  for (let f = 1; f < DURATION; f++) {
    const t = f / FPS; const k = Math.floor((argaZ(t) * 1.6) / Math.PI);
    if (argaWalking(t) && k !== last) steps.push(f);
    last = k;
  }
}
const at = (s: number) => Math.round(s * FPS);

export const Main: React.FC = () => {
  return (
    <AbsoluteFill style={{background: '#000'}}>
      <ThreeCanvas width={1080} height={1920} shadows camera={{fov: 46, near: 0.1, far: 500, position: [0, 5, 50]}} style={{width: 1080, height: 1920}}>
        <World />
      </ThreeCanvas>
      <Overlay />
      <Subtitles />
      <Audio src={staticFile('vo.mp3')} volume={1} />
      <Audio src={staticFile('music.wav')} volume={(f) => 0.3 * interpolate(f / FPS, [0, 3], [0, 1], {extrapolateRight: 'clamp'})} />
      <Audio src={staticFile('wind.wav')} volume={(f) => interpolate(f / FPS, [0, st(6), st(7)], [0.05, 0.1, 0.22], {extrapolateRight: 'clamp'})} />
      <Audio src={staticFile('crickets.wav')} volume={(f) => interpolate(f / FPS, [st(4), st(6)], [0, 0.17], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'})} />
      {steps.map((f) => (<Sequence key={f} from={f} durationInFrames={9}><Audio src={staticFile('step.wav')} volume={0.45} /></Sequence>))}
      <Sequence from={at(st(7) + 0.6)}><Audio src={staticFile('creak.wav')} volume={0.7} /></Sequence>
      <Sequence from={at(st(7))}><Audio src={staticFile('sting.wav')} volume={0.4} /></Sequence>
      <Sequence from={at(slamT)}><Audio src={staticFile('slam.wav')} volume={0.95} /></Sequence>
      <Sequence from={at(slamT)}><Audio src={staticFile('sting.wav')} volume={0.5} /></Sequence>
      <Sequence from={at(st(13))}><Audio src={staticFile('sting.wav')} volume={0.35} /></Sequence>
    </AbsoluteFill>
  );
};
