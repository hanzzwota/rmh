import React from 'react';
import * as THREE from 'three';
import {rnd} from './util';

const Bx = ({p, s, c, r, e, ei = 0, cast = true}: any) => (
  <mesh position={p} scale={s} rotation={r} castShadow={cast} receiveShadow>
    <boxGeometry args={[1, 1, 1]} />
    <meshStandardMaterial color={c} flatShading emissive={e || '#000'} emissiveIntensity={ei} />
  </mesh>
);
const Cyl = ({p, a, c, r, cast = true}: any) => (
  <mesh position={p} rotation={r} castShadow={cast}>
    <cylinderGeometry args={a} /><meshStandardMaterial color={c} flatShading />
  </mesh>
);
const Ico = ({p, s, c}: any) => (
  <mesh position={p} scale={s} castShadow>
    <icosahedronGeometry args={[1, 1]} /><meshStandardMaterial color={c} flatShading />
  </mesh>
);

export const BigTree: React.FC<{p: number[]; h?: number; t: number; i: number}> = ({p, h = 7, t, i}) => (
  <group position={p as any}>
    <Cyl p={[0, h / 2, 0]} a={[0.35, 0.6, h, 7]} c="#4a3626" />
    <group position={[0, h, 0]} rotation={[0, 0, Math.sin(t * 0.9 + i) * 0.015]}>
      <Ico p={[0, 1.2, 0]} s={[2.6, 2.2, 2.6]} c="#2f5d2b" />
      <Ico p={[1.5, 0.3, 0.6]} s={[1.9, 1.6, 1.9]} c="#386b30" />
      <Ico p={[-1.4, 0.2, -0.5]} s={[2, 1.7, 2]} c="#2b5427" />
    </group>
  </group>
);
export const Coconut: React.FC<{p: number[]; t: number; i: number}> = ({p, t, i}) => (
  <group position={p as any} rotation={[0, i, 0]}>
    <Cyl p={[0.3, 3.2, 0]} a={[0.2, 0.3, 6.4, 6]} c="#7a5c3a" r={[0, 0, -0.1]} />
    <group position={[0.6, 6.4, 0]} rotation={[0, 0, Math.sin(t + i) * 0.02]}>
      {[0, 1, 2, 3, 4, 5].map((k) => (
        <group key={k} rotation={[0, (k * Math.PI) / 3, 0]}>
          <Bx p={[1.2, -0.15, 0]} s={[2.6, 0.06, 0.45]} c="#3f7a2e" r={[0, 0, -0.35]} />
        </group>
      ))}
      <Ico p={[0, -0.3, 0.2]} s={[0.22, 0.22, 0.22]} c="#6b4a22" />
    </group>
  </group>
);
export const Banana: React.FC<{p: number[]; t: number; i: number}> = ({p, t, i}) => (
  <group position={p as any}>
    <Cyl p={[0, 1.1, 0]} a={[0.18, 0.25, 2.2, 6]} c="#6d8f3a" />
    {[0, 1, 2, 3, 4].map((k) => (
      <group key={k} position={[0, 2.2, 0]} rotation={[0, (k * 2 * Math.PI) / 5 + i, 0]}>
        <Bx p={[0.9, -0.1, 0]} s={[1.9, 0.04, 0.6]} c="#4f9a35" r={[0, 0, -0.4 + Math.sin(t * 1.5 + k + i) * 0.04]} />
      </group>
    ))}
  </group>
);
export const Hut: React.FC<{p: number[]; ry?: number; wall?: string; roof?: string; warung?: boolean}> = ({p, ry = 0, wall = '#b08a5c', roof = '#8a4b38', warung}) => (
  <group position={p as any} rotation={[0, ry, 0]}>
    <Bx p={[0, 1.4, 0]} s={[4.4, 2.8, 3.6]} c={wall} />
    <mesh position={[0, 3.4, 0]} rotation={[0, Math.PI / 4, 0]} scale={[1.9, 1, 1.55]} castShadow>
      <coneGeometry args={[1.5, 1.8, 4]} /><meshStandardMaterial color={roof} flatShading />
    </mesh>
    <Bx p={[0, 1, 1.82]} s={[0.9, 2, 0.06]} c="#5a3a22" />
    <Bx p={[1.4, 1.7, 1.82]} s={[0.9, 0.8, 0.06]} c="#f2d98a" e="#ffcc66" ei={0.25} />
    {warung && (<>
      <Bx p={[0, 2.2, 2.4]} s={[4.2, 0.12, 1.6]} c="#c0392b" r={[0.25, 0, 0]} />
      <Bx p={[0, 0.5, 2.1]} s={[3.2, 1, 0.6]} c="#7a5230" />
      <Bx p={[-1, 1.2, 2.1]} s={[0.4, 0.4, 0.3]} c="#e8c547" />
      <Bx p={[0.2, 1.2, 2.1]} s={[0.4, 0.4, 0.3]} c="#d9534f" />
    </>)}
  </group>
);
export const Pole: React.FC<{p: number[]; lamp?: number}> = ({p, lamp = 0}) => (
  <group position={p as any}>
    <Cyl p={[0, 3.5, 0]} a={[0.1, 0.14, 7, 6]} c="#5b5148" />
    <Bx p={[0, 6.5, 0]} s={[1.6, 0.1, 0.1]} c="#3b352f" />
    <Bx p={[0.5, 6.1, 0]} s={[0.4, 0.2, 0.4]} c="#f8e9a0" e="#ffd86b" ei={lamp * 2.5} />
    {lamp > 0.3 && <pointLight position={[0.5, 5.8, 0]} color="#ffd98a" intensity={14 * lamp} distance={12} />}
  </group>
);
export const Fence: React.FC<{from: number[]; to: number[]; broken?: boolean; seed?: number}> = ({from, to, broken, seed = 1}) => {
  const n = Math.max(2, Math.round(Math.hypot(to[0] - from[0], to[2] - from[2]) / 0.45));
  const ang = Math.atan2(to[0] - from[0], to[2] - from[2]);
  return (
    <group>
      {Array.from({length: n}).map((_, i) => {
        const u = i / (n - 1);
        const x = from[0] + (to[0] - from[0]) * u, z = from[2] + (to[2] - from[2]) * u;
        const fall = broken && rnd(i + seed * 17) > 0.65;
        const h = fall ? 0.7 : 1.4 + rnd(i + seed) * 0.3;
        return <Cyl key={i} p={[x, h / 2 - (fall ? 0.1 : 0), z]} a={[0.045, 0.05, h, 5]} c={broken ? '#8a7a4a' : '#b5a15a'} r={fall ? [0.5 * (rnd(i) > 0.5 ? 1 : -1), 0, 0.4] : [0, 0, 0]} />;
      })}
      <Bx p={[(from[0] + to[0]) / 2, 0.55, (from[2] + to[2]) / 2]} s={[0.05, 0.06, Math.hypot(to[0] - from[0], to[2] - from[2])]} c="#8f7d3e" r={[0, ang, 0]} />
    </group>
  );
};
export const Grass: React.FC<{t: number; area: number[]; n: number}> = ({t, area, n}) => (
  <group>
    {Array.from({length: n}).map((_, i) => {
      const x = area[0] + rnd(i * 3) * (area[1] - area[0]), z = area[2] + rnd(i * 5 + 1) * (area[3] - area[2]);
      const h = 0.5 + rnd(i * 7) * 0.9;
      return (
        <mesh key={i} position={[x, h / 2, z]} rotation={[0, 0, Math.sin(t * 1.8 + i) * 0.12]}>
          <coneGeometry args={[0.07, h, 4]} /><meshStandardMaterial color={rnd(i) > 0.5 ? '#6f8b34' : '#8aa043'} flatShading />
        </mesh>
      );
    })}
  </group>
);

export const House: React.FC<{open: number; lit: number; t: number}> = ({open, lit, t}) => {
  const flick = lit * (0.85 + Math.sin(t * 13) * 0.05 + Math.sin(t * 5.3) * 0.05);
  return (
    <group>
      <Bx p={[0, 0.25, 0]} s={[6.6, 0.5, 5.6]} c="#4d3f33" />
      <Bx p={[0, 2.0, 0]} s={[6, 3, 5]} c="#6b5442" />
      {[-2.4, -1.2, 0, 1.2, 2.4].map((x, i) => <Bx key={i} p={[x, 2.0, 2.52]} s={[0.05, 3, 0.04]} c="#4e3b2c" />)}
      <mesh position={[0, 4.6, 0]} rotation={[0, Math.PI / 4, 0]} scale={[2.35, 1, 1.95]} castShadow>
        <coneGeometry args={[1.5, 2.2, 4]} /><meshStandardMaterial color="#6e4a40" flatShading />
      </mesh>
      {/* ambang pintu: bagian dalam gelap kehangatan */}
      <Bx p={[0, 1.6, 2.51]} s={[1.1, 2.2, 0.02]} c="#120a05" e="#ffae3a" ei={0.7 * open > 0 ? 0.9 : 0} cast={false} />
      <group position={[-0.55, 1.6, 2.58]} rotation={[0, -open, 0]}>
        <Bx p={[0.55, 0, 0]} s={[1.1, 2.2, 0.08]} c="#5b3d28" />
        <Bx p={[0.9, -0.1, 0.06]} s={[0.06, 0.1, 0.06]} c="#9a8a50" />
      </group>
      {open > 0.05 && <pointLight position={[0, 1.4, 3.4]} color="#ffb040" intensity={10 * Math.min(1, open * 3)} distance={9} />}
      {/* jendela: tertutup, cahaya kuning mengintip dari celah */}
      {[-1, 1].map((s) => (
        <group key={s} position={[s * 2, 2.3, 2.52]}>
          <Bx p={[0, 0, -0.02]} s={[1.1, 1.0, 0.03]} c="#ffcb52" e="#ffb830" ei={lit * 2.2} cast={false} />
          {s === -1 && <Bx p={[Math.sin(t * 0.8) * 0.12, -0.05, 0]} s={[0.28, 0.7, 0.02]} c="#1a0f08" cast={false} />}
          {[-0.36, -0.12, 0.12, 0.36].map((y, i) => <Bx key={i} p={[0, y, 0.03]} s={[1.2, 0.17, 0.05]} c="#4a3524" />)}
        </group>
      ))}
      <pointLight position={[-2, 2.3, 3.6]} color="#ffbb44" intensity={9 * lit} distance={10} />
    </group>
  );
};
