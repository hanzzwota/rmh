import {K} from './util';
export const FPS = 30;
export const DURATION = 1917; // 63.87 s
export const END = DURATION / FPS;

// Kalimat naskah (urutan = urutan narasi). Waktu mulai diperkirakan dari panjang teks.
export const SENTENCES = [
  'Di ujung sebuah kampung, ada satu rumah tua yang sudah puluhan tahun tidak pernah dihuni.',
  'Tapi anehnya, setiap malam selalu ada lampu yang menyala dari dalam rumah itu.',
  'Menurut warga sekitar, rumah tersebut sudah lama ditinggalkan pemiliknya.',
  'Halamannya dipenuhi rumput liar, pagar kayunya mulai roboh, dan jendelanya selalu tertutup rapat.',
  'Tidak ada yang berani mendekat, apalagi masuk ke dalamnya.',
  'Sampai suatu malam, seorang pemuda yang sedang pulang melewati rumah itu melihat sesuatu yang membuatnya berhenti.',
  'Pintu rumah yang biasanya tertutup, malam itu terbuka sedikit.',
  'Dari dalam terdengar suara seperti seseorang sedang berjalan.',
  'Pemuda itu mencoba melihat melalui celah pintu.',
  'Tapi anehnya, tidak ada siapa-siapa di dalam.',
  'Saat dia berbalik untuk pergi, tiba-tiba terdengar suara pintu tertutup tepat di belakangnya.',
  'Sejak malam itu, dia tidak pernah lagi melewati jalan di ujung kampung tersebut.',
  'Tapi satu pertanyaan masih belum terjawab... kalau rumah itu benar-benar kosong, siapa yang menyalakan lampunya setiap malam?',
];
// >>> Jika subtitle terasa geser, ubah 2 angka ini atau isi MANUAL_STARTS (detik) <<<
const LEAD = 0.5, TAIL = 0.8;
export const MANUAL_STARTS: number[] | null = null;
const w = SENTENCES.map((s) => s.length + (s.includes('...') ? 14 : 0) + 8);
const sum = w.reduce((a, b) => a + b, 0);
const avail = END - LEAD - TAIL;
let acc = 0;
const auto = w.map((x) => {const s = LEAD + (acc / sum) * avail; acc += x; return s;});
export const STARTS = MANUAL_STARTS || auto;
export const st = (i: number) => STARTS[i - 1];
export const et = (i: number) => (i < SENTENCES.length ? STARTS[i] - 0.15 : END - TAIL);
export const slamT = st(11) + (et(11) - st(11)) * 0.62;

// posisi Arga di jalan (sumbu z). Rumah di z=0, desa di z>0.
export const argaZ = (t: number) =>
  K(t, [
    [0, 46], [st(6) - 0.5, 46], [et(6) + 0.8, 8.5], [st(9), 8.5], [st(9) + 3, 3.9],
    [st(11), 3.9], [st(11) + 0.9, 3.9], [slamT, 5.4], [st(12), 5.4], [st(13) + 3.5, 36], [END, 36],
  ], false)[0];
export const argaWalking = (t: number) => Math.abs(argaZ(t + 0.05) - argaZ(t)) > 0.002;
